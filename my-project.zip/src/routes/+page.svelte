<h1 class="text-5xl font-bold pt-4 text-center">
  Hello world!
</h1>

<style lang="postcss">
  :global(html) {
    background-color: theme(colors.gray.100);
  }
</style>